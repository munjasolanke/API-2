﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace SEL_API_Relay.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PageInfo",
                columns: table => new
                {
                    CurrentPage = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstPageAbsoluteUrl = table.Column<string>(nullable: true),
                    FirstPageUrl = table.Column<string>(nullable: true),
                    LastPageAbsoluteUrl = table.Column<string>(nullable: true),
                    LastPageUrl = table.Column<string>(nullable: true),
                    NextPageAbsoluteUrl = table.Column<string>(nullable: true),
                    NextPageUrl = table.Column<string>(nullable: true),
                    PageSize = table.Column<string>(nullable: true),
                    PreviousPageAbsoluteUrl = table.Column<string>(nullable: true),
                    PreviousPageUrl = table.Column<string>(nullable: true),
                    TotalPages = table.Column<int>(nullable: false),
                    TotalRecords = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PageInfo", x => x.CurrentPage);
                });

            migrationBuilder.CreateTable(
                name: "ResponseStatus",
                columns: table => new
                {
                    ErrorCode = table.Column<string>(nullable: false),
                    Message = table.Column<string>(nullable: true),
                    StackTrace = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResponseStatus", x => x.ErrorCode);
                });

            migrationBuilder.CreateTable(
                name: "Error",
                columns: table => new
                {
                    ErrorCode = table.Column<string>(nullable: false),
                    FieldName = table.Column<string>(nullable: true),
                    Message = table.Column<string>(nullable: true),
                    ResponseStatusErrorCode = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Error", x => x.ErrorCode);
                    table.ForeignKey(
                        name: "FK_Error_ResponseStatus_ResponseStatusErrorCode",
                        column: x => x.ResponseStatusErrorCode,
                        principalTable: "ResponseStatus",
                        principalColumn: "ErrorCode",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Relay_Models",
                columns: table => new
                {
                    DbHost = table.Column<string>(nullable: false),
                    Version = table.Column<string>(nullable: true),
                    ResponseStatusErrorCode = table.Column<string>(nullable: true),
                    PageInfoCurrentPage = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Relay_Models", x => x.DbHost);
                    table.ForeignKey(
                        name: "FK_Relay_Models_PageInfo_PageInfoCurrentPage",
                        column: x => x.PageInfoCurrentPage,
                        principalTable: "PageInfo",
                        principalColumn: "CurrentPage",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Relay_Models_ResponseStatus_ResponseStatusErrorCode",
                        column: x => x.ResponseStatusErrorCode,
                        principalTable: "ResponseStatus",
                        principalColumn: "ErrorCode",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DataDevice",
                columns: table => new
                {
                    UniqueDeviceId = table.Column<string>(nullable: false),
                    DbHost = table.Column<string>(nullable: true),
                    Description = table.Column<string>(nullable: true),
                    DeviceId = table.Column<string>(nullable: true),
                    DeviceManagerLocation = table.Column<string>(nullable: true),
                    DeviceName = table.Column<string>(nullable: true),
                    DeviceType = table.Column<string>(nullable: true),
                    FidString = table.Column<string>(nullable: true),
                    FirmwareVersion = table.Column<string>(nullable: true),
                    IsCommissioned = table.Column<bool>(nullable: false),
                    IsEnabled = table.Column<bool>(nullable: false),
                    IsInService = table.Column<bool>(nullable: false),
                    MeteringPointId = table.Column<string>(nullable: true),
                    MeteringPointName = table.Column<string>(nullable: true),
                    Notes = table.Column<string>(nullable: true),
                    PartNumber = table.Column<string>(nullable: true),
                    RecorderConfigDeviceIdentifier = table.Column<string>(nullable: true),
                    RecorderConfigDeviceSerialNumber = table.Column<string>(nullable: true),
                    RecorderConfigDeviceType = table.Column<string>(nullable: true),
                    RecorderConfigFirmwareIdentifier = table.Column<string>(nullable: true),
                    RecorderConfigTerminalIdentifier = table.Column<string>(nullable: true),
                    RecorderConfigTimeSource = table.Column<string>(nullable: true),
                    RecorderConfigWiringForm = table.Column<string>(nullable: true),
                    SerialNumber = table.Column<string>(nullable: true),
                    StationName = table.Column<string>(nullable: true),
                    TimeZoneName = table.Column<string>(nullable: true),
                    Relay_ModelsDbHost = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DataDevice", x => x.UniqueDeviceId);
                    table.ForeignKey(
                        name: "FK_DataDevice_Relay_Models_Relay_ModelsDbHost",
                        column: x => x.Relay_ModelsDbHost,
                        principalTable: "Relay_Models",
                        principalColumn: "DbHost",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DataDevice_Relay_ModelsDbHost",
                table: "DataDevice",
                column: "Relay_ModelsDbHost");

            migrationBuilder.CreateIndex(
                name: "IX_Error_ResponseStatusErrorCode",
                table: "Error",
                column: "ResponseStatusErrorCode");

            migrationBuilder.CreateIndex(
                name: "IX_Relay_Models_PageInfoCurrentPage",
                table: "Relay_Models",
                column: "PageInfoCurrentPage");

            migrationBuilder.CreateIndex(
                name: "IX_Relay_Models_ResponseStatusErrorCode",
                table: "Relay_Models",
                column: "ResponseStatusErrorCode");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DataDevice");

            migrationBuilder.DropTable(
                name: "Error");

            migrationBuilder.DropTable(
                name: "Relay_Models");

            migrationBuilder.DropTable(
                name: "PageInfo");

            migrationBuilder.DropTable(
                name: "ResponseStatus");
        }
    }
}
