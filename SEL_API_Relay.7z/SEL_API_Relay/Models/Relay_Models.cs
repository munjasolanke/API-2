﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;


namespace SEL_API_Relay.Models
{
    public class Relay_Models
    {
        public string Version { get; set; }
        //public CustomAttributes CustomAttributes { get; set; }
        [Key]
        public string DbHost { get; set; }
        public ResponseStatus ResponseStatus { get; set; }
        public DataDevice[] DataDevice { get; set; }
        public PageInfo PageInfo { get; set; }
    }

    public class EventReport
    {
        public string Version { get; set; }
        //public CustomAttributes CustomAttributes { get; set; }
        [Key]
        public string DbHost { get; set; }
        public ResponseStatus ResponseStatus { get; set; }
        public DataEventReport[] DataEventReport { get; set; }
        public PageInfo PageInfo { get; set; }
    }
    public class Error
    {
        [Key]
        public string ErrorCode { get; set; }
        public string FieldName { get; set; }
        public string Message { get; set; }
        //public Meta Meta { get; set; }
    }

    public class ResponseStatus
    {
        [Key]
        public string ErrorCode { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public IList<Error> Errors { get; set; }
        //public Meta Meta{ get; set; }
    }

    public class DataDevice
    {
        public string DbHost { get; set; }
        public string Description { get; set; }
        public string DeviceId { get; set; }
        public string DeviceManagerLocation { get; set; }
        public string DeviceName { get; set; }
        public string DeviceType { get; set; }
        public string FidString { get; set; }
        public string FirmwareVersion { get; set; }
        public bool IsCommissioned { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsInService { get; set; }
        public string MeteringPointId { get; set; }
        public string MeteringPointName { get; set; }
        public string Notes { get; set; }
        public string PartNumber { get; set; }
        public string RecorderConfigDeviceIdentifier { get; set; }
        public string RecorderConfigDeviceSerialNumber { get; set; }
        public string RecorderConfigDeviceType { get; set; }
        public string RecorderConfigFirmwareIdentifier { get; set; }
        public string RecorderConfigTerminalIdentifier { get; set; }
        public string RecorderConfigTimeSource { get; set; }
        public string RecorderConfigWiringForm { get; set; }
        public string SerialNumber { get; set; }
        public string StationName { get; set; }
        public string TimeZoneName { get; set; }
        
        [Key]
        public string UniqueDeviceId { get; set; }
    }

    public class PageInfo
    {
        [Key]
        public int CurrentPage { get; set; }
        public string FirstPageAbsoluteUrl { get; set; }
        public string FirstPageUrl { get; set; }
        public string LastPageAbsoluteUrl { get; set; }
        public string LastPageUrl { get; set; }
        public string NextPageAbsoluteUrl { get; set; }
        public string NextPageUrl { get; set; }
        public string PageSize { get; set; }
        public string PreviousPageAbsoluteUrl { get; set; }
        public string PreviousPageUrl { get; set; }
        public int TotalPages { get; set; }
        public string TotalRecords { get; set; }
    }
    public class CustomAttributes
    {
       
    }

    public class Meta
    {
       
    }

    //EventReport model structure Data
    public class DataEventReport
    {
        public string DbHost { get; set; }
        public string Description { get; set; }
        public string DeviceId { get; set; }
        public string DeviceManagerLocation { get; set; }
        public string DeviceName { get; set; }
        public string DeviceType { get; set; }
        public string FidString { get; set; }
        public string FirmwareVersion { get; set; }
        public bool IsCommissioned { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsInService { get; set; }
        public string MeteringPointId { get; set; }
        public string MeteringPointName { get; set; }
        public string Notes { get; set; }
        public string PartNumber { get; set; }
        public string RecorderConfigDeviceIdentifier { get; set; }
        public string RecorderConfigDeviceSerialNumber { get; set; }
        public string RecorderConfigDeviceType { get; set; }
        public string RecorderConfigFirmwareIdentifier { get; set; }
        public string RecorderConfigTerminalIdentifier { get; set; }
        public string RecorderConfigTimeSource { get; set; }
        public string RecorderConfigWiringForm { get; set; }
        public string SerialNumber { get; set; }
        public string StationName { get; set; }
        public string TimeZoneName { get; set; }
        public string UniqueDeviceId { get; set; }
        public bool AcknowledgedByUser { get; set; }
        public string DeviceEventId { get; set; }
        public string EventFileUrl { get; set; }
        public string EventNumber { get; set; }
        public string EventType { get; set; }
        public string Fid { get; set; }
        public string FilePathAndName { get; set; }
        public string FileType { get; set; }
        public string MaxFaultCurrents { get; set; }
        public string Mid { get; set; }
        public string RetrievalCmdUsed { get; set; }
        public string RetrievedTimestamp { get; set; }
        public string Rid { get; set; }
        public string Targets { get; set; }
        public string Tid { get; set; }
        public string Timestamp { get; set; }

        [Key]
        public string UniqueDeviceEventId { get; set; }
    }

}
