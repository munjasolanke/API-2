﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using SEL_API_Relay.Models;
using Newtonsoft.Json;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using SEL_API_Relay.DataAccess;

namespace SEL_API_Relay.Controllers
{
    public class HomeController : Controller
    {
        public ApplicationDbContext dbContext;

        /*
            These lines are needed to use the Database context,
            define the connection to the API, and use the
            HttpClient to request data from the API
        */


        //Base URL for the SEL API. Method specific URLs are appended to this base URL.
        string BASE_URL = "http://localhost:5230/";
        //string BASE_URL = "http://TRINITYTRNGPC:5230/";
        HttpClient httpClient;

        /*
         These lines create a Constructor for the HomeController.
         Then, the Database context is defined in a variable.
         Then, an instance of the HttpClient is created.
        */
        public HomeController(ApplicationDbContext context)
        {
            dbContext = context;
            httpClient = new HttpClient();
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(new
                System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        //Relay_Models - get device data method
        public Relay_Models GetRelay_Models()
        {
            string SEL_Relay_Device_API_PATH = BASE_URL + "api/device";
            string Relay_Models_List = "";
            //List<Relay_Models> relay_Models = null;
            Relay_Models relay_Models = null;


            //Connect to SEL Database API and retrieve the information 
            httpClient.BaseAddress = new Uri(SEL_Relay_Device_API_PATH);

            try
            {
                HttpResponseMessage response = httpClient.GetAsync(SEL_Relay_Device_API_PATH).GetAwaiter().GetResult();

                //Read the Json objects in the API response
                if (response.IsSuccessStatusCode)
                {
                    Relay_Models_List =  response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                }

                //Now parse Json string to C# objects
                if (!Relay_Models_List.Equals(""))
                {
                    // JsonConvert is part of the NewtonSoft.Json Nuget package
                    relay_Models = JsonConvert.DeserializeObject <Relay_Models>(Relay_Models_List); //<Models.Relay_Models>(Relay_Models_List);
                }

            }
            catch(Exception e)
            {
                // This is a useful place to insert a breakpoint and observe the error message
                Console.WriteLine(e.Message);
            }

            return relay_Models;
        }

        //Relay_Models - get Relay_EventReport data method - Relay_EventReport_List
        public EventReport GetRelay_EventReport()
        {
            string SEL_EventReport_API_PATH = BASE_URL + "api/eventreport";
            string EventReport_List = "";
            //List<Relay_Models> relay_Models = null;
            EventReport eventReport = null;


            //Connect to SEL Database API and retrieve the information 
            httpClient.BaseAddress = new Uri(SEL_EventReport_API_PATH);

            try
            {
                HttpResponseMessage response = httpClient.GetAsync(SEL_EventReport_API_PATH).GetAwaiter().GetResult();

                //Read the Json objects in the API response
                if (response.IsSuccessStatusCode)
                {
                    EventReport_List = response.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                }

                //Now parse Json string to C# objects
                if (!EventReport_List.Equals(""))
                {
                    eventReport = JsonConvert.DeserializeObject<EventReport>(EventReport_List);
                }
            }
            catch (Exception e)
            {
                // This is a useful place to insert a breakpoint and observe the error message
                Console.WriteLine(e.Message);
            }

            return eventReport;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Relay_Models()
        {
            HomeController webHandler = new HomeController(dbContext);
            Relay_Models relay_Models_view = webHandler.GetRelay_Models();
            return View(relay_Models_view);
        }
        public IActionResult EventReport()
        {
            HomeController webHandler = new HomeController(dbContext);
            EventReport eventReport_view = webHandler.GetRelay_EventReport();
            return View(eventReport_view);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
