﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SEL_API_Relay.Models;
using Microsoft.EntityFrameworkCore;

namespace SEL_API_Relay.DataAccess
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }
        public DbSet<Relay_Models> Relay_Models { get; set; }
        public DbSet<Relay_Models> EventReport { get; set; }

    }
}
